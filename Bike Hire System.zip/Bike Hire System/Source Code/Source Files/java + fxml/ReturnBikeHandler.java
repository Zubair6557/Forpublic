package bikeHireApplication;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ReturnBikeHandler implements Initializable{

	
	@FXML
	private Label bikeNo;
	@FXML
	private Label bikeType;
	@FXML
	private Label color;
	@FXML
	private Label gender;
	@FXML
	private Label hourlyRate;
	@FXML
	private Label deposit;
	@FXML
	private Label hireHours;
	@FXML
	private Label hireDays;
	@FXML
	private Label size;
	@FXML
	private Label make;
	@FXML
	private Label dailyRate;	
	@FXML
	private Label paidAmount;
	@FXML
	private Label refundableAmount;
	@FXML
	private Label name;
	@FXML
	private Label phone;
	@FXML
	private Label address;
	@FXML
	private Label comboError;
	@FXML
	private Label numericError;
	@FXML
	private Label hireDate;
	@FXML
	private Label currentDate;
	
	@FXML
	private TextField lateHours;
	@FXML
	private TextField lateDays;
	
	@FXML
	private ComboBox<String> bikeCondition;
	
	@FXML
	private Button returnBike;
	@FXML
	private Button back;
	
	
	public static String rCusName;
	public static String rCusPhone;
	public static String condition; 
	public static String lateReturnFee;
	public static boolean validated = false;
	public static String refundable;
	public static String lateReturnHours;
	public static String lateReturnDays;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		String str;
		try {
			str = HiredBikesFileHandler.getHiredBikeDetails(HomeHandler.filledName, HomeHandler.filledPhone);
			StringTokenizer newToken = new StringTokenizer(str, ">");
			
			name.setText(newToken.nextToken());
			phone.setText(newToken.nextToken());
			address.setText(newToken.nextToken());
			hireDate.setText(newToken.nextToken());
			bikeNo.setText(newToken.nextToken());
			bikeType.setText(newToken.nextToken());
			color.setText(newToken.nextToken());
			gender.setText(newToken.nextToken());
			make.setText(newToken.nextToken());
			size.setText(newToken.nextToken());
			dailyRate.setText(newToken.nextToken());
			hourlyRate.setText(newToken.nextToken());
			deposit.setText(newToken.nextToken());
			hireHours.setText(newToken.nextToken());
			hireDays.setText(newToken.nextToken());
			paidAmount.setText(newToken.nextToken());
			
			
			currentDate.setText(new Date().toString());
			rCusName = name.getText();
			rCusPhone = phone.getText();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	@FXML
	public void backButthonPressed(ActionEvent e) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Home.fxml"));
		Scene scene = new Scene(root);
		
		Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
		
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Northampton Bike Hire System | Home");
		secondaryStage.show();
	}

	@FXML
	public void returnButtonPressed(ActionEvent e) throws Exception
	{
		if(bikeCondition.getValue() != null)
		{
			if(bikeCondition.getValue().equalsIgnoreCase("Good"))
			{
				if(!lateHours.getText().isEmpty() && lateDays.getText().isEmpty())//Late Hours
				{
					if(Validator.numericValidation(lateHours, numericError, "Please enter only numbers from 0-9"))
					{
						validated = true;
						lateReturnFee = Integer.toString(Integer.parseInt(lateHours.getText())*15);
					}
					
				}
				else if(lateHours.getText().isEmpty() && !lateDays.getText().isEmpty())//Days Late
				{
					if(Validator.numericValidation(lateDays, numericError, "Please enter only numbers from 0-9"))
					{
						validated = true;
						lateReturnFee = Integer.toString(Integer.parseInt(lateDays.getText())*24*15);
					}
				}
				else if(!lateHours.getText().isEmpty() && !lateDays.getText().isEmpty())//Both Late
				{
					if((Validator.numericValidation(lateHours, numericError, "Please enter only numbers from 0-9")) && (Validator.numericValidation(lateDays, numericError, "Please enter only numbers from 0-9")))
					{
						validated = true;
						int lDays = Integer.parseInt(lateDays.getText());
						int lHours = Integer.parseInt(lateHours.getText());
						int lDaysFee = lDays*24*15;
						int lHoursFee = lHours*15;
						lateReturnFee = Integer.toString(lDaysFee+lHoursFee);
						
					}
				}
				else if(lateHours.getText().isEmpty() && lateDays.getText().isEmpty())
				{
					validated = true;	
					lateReturnFee  = "0" ;
				}
				
				if(validated)
				{
					int lateFee = Integer.parseInt(lateReturnFee);
					int depositAmount = Integer.parseInt(deposit.getText());
					refundable= Integer.toString(depositAmount-lateFee);
					condition = "Good";
					lateReturnHours = lateHours.getText();
					lateReturnDays = lateDays.getText();
					
					Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/ReturnInvoice.fxml"));
					Scene scene = new Scene(root);
					Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
					secondaryStage.setScene(scene);
					secondaryStage.setTitle("Northampton Bike Hire System | Return Invoice");
					secondaryStage.show();
					
					HiredBikesFileHandler.removeHiredBike(name.getText(), phone.getText());//Removing Record from HiredStock
					AvailableStockFileHandler bike = new AvailableStockFileHandler();
					bike.category = bikeType.getText();
					bike.bikeNo = bikeNo.getText();
					bike.color = color.getText();
					bike.gender = gender.getText();
					bike.frameSize = size.getText();
					bike.make = make.getText();
				
					AvailableStockFileHandler.updateAvailableStock(bike);
					
				}
			}
			else if(bikeCondition.getValue().equalsIgnoreCase("Damaged"))
			{
				if(!lateHours.getText().isEmpty() && lateDays.getText().isEmpty())//Only Hours Late
				{
					if(Validator.numericValidation(lateHours, numericError, "Please enter only numbers from 0-9"))
					{
						validated = true;
						lateReturnFee = Integer.toString(Integer.parseInt(lateHours.getText())*15);
					}
				}
				else if(lateHours.getText().isEmpty() && !lateDays.getText().isEmpty())//Only Days Late
				{
					if(Validator.numericValidation(lateDays, numericError, "Please enter only numbers from 0-9"))
					{
						validated = true;
						lateReturnFee = Integer.toString(Integer.parseInt(lateDays.getText())*24*15);
					}
				}
				else if(!lateHours.getText().isEmpty() && !lateDays.getText().isEmpty())//Both Days Late
				{
					if((Validator.numericValidation(lateHours, numericError, "Please enter only numbers from 0-9")) && (Validator.numericValidation(lateDays, numericError, "Please enter only numbers from 0-9")))
					{
						validated = true;
						int lDays = Integer.parseInt(lateDays.getText());
						int lHours = Integer.parseInt(lateHours.getText());
						int lDaysFee = lDays*24*15;
						int lHoursFee = lHours*15;
						lateReturnFee = Integer.toString(lDaysFee+lHoursFee);
					}
					
				}
				else if(lateHours.getText().isEmpty() && lateDays.getText().isEmpty())
				{
					validated = true;	
					lateReturnFee = "0";
				}
				
				if(validated)
				{
					
					int lateFee = Integer.parseInt(lateReturnFee);
					int depositAmount = 0;
					refundable = Integer.toString(depositAmount-lateFee);
					condition = "Damaged";
					
					lateReturnHours = lateHours.getText();
					lateReturnDays = lateDays.getText();
					
					Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/ReturnInvoice.fxml"));
					Scene scene = new Scene(root);
					Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
					secondaryStage.setScene(scene);
					secondaryStage.setTitle("Northampton Bike Hire System | Return Invoice");
					secondaryStage.show();
					
					HiredBikesFileHandler.removeHiredBike(name.getText(), phone.getText());//Removing Record from HiredStock
					AvailableStockFileHandler bike = new AvailableStockFileHandler();
					bike.category = bikeType.getText();
					bike.bikeNo = bikeNo.getText();
					bike.color = color.getText();
					bike.gender = gender.getText();
					bike.frameSize = size.getText();
					bike.make = make.getText();
				
					AvailableStockFileHandler.updateAvailableStock(bike);
				}		
			}
		}
		else
		{
			comboError.setText("Please select bike's condition");
		}	
		
	}
}

package bikeHireApplication;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HireBikeHandler implements Initializable{

	@FXML
	private Button calculate;
	@FXML
	private Button back;
	
	@FXML
	private Label bikeType;
	@FXML
	private Label bikeNo;
	@FXML
	private Label bikeMake;
	@FXML
	private Label bikeColor;
	@FXML
	private Label bikeGender;
	@FXML
	private Label bikeSize;
	@FXML
	private Label bikeHourlyRate;
	@FXML
	private Label bikeDailyRate;
	@FXML
	private Label bikeDeposit;
	@FXML
	private Label phoneError;
	@FXML
	private Label emptyField;
	@FXML
	private Label hireHoursNumericError;
	@FXML
	private Label hireDaysNumericError;
	@FXML
	private Label CurrentDate;
	
	@FXML
	private TextField cusName;
	@FXML
	private TextField cusPhone;
	@FXML
	private TextField cusAddress;
	@FXML
	private TextField hireHours;
	@FXML
	private TextField hireDays;
	
	//Static Data Members
	public static String totalAmount;
	public static String filledName="";
	public static String filledPhone="";
	public static String filledAddress="";
	public static String filledHireHours="";
	public static String filledHireDays="";
	public static String searchedData="";
	public static Date hireDate;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		 
		hireDate = new Date();
		CurrentDate.setText(hireDate.toString());
		AvailableStockFileHandler bike = new AvailableStockFileHandler();
		bike.category = HomeHandler.selectedCategory;
		bike.color = HomeHandler.selectedcolor;
		bike.gender = HomeHandler.selectedGender;
		bike.frameSize = HomeHandler.selectedSize;
		
		cusName.setText(filledName);
		cusAddress.setText(filledAddress);
		cusPhone.setText(filledPhone);
		hireHours.setText(filledHireHours);
		hireDays.setText(filledHireDays);
		
		try {
			searchedData = AvailableStockFileHandler.getAvailableBikeDetail(bike);
			if(!searchedData.equalsIgnoreCase(""))
			{
				
				StringTokenizer token = new StringTokenizer(searchedData, ">");
				
				bikeType.setText(token.nextToken());
				bikeGender.setText(token.nextToken());
				bikeSize.setText(token.nextToken());
				bikeColor.setText(token.nextToken());
				token.nextToken();
				bikeNo.setText(token.nextToken());
				bikeMake.setText(token.nextToken());
				bikeHourlyRate.setText(token.nextToken());
				bikeDailyRate.setText(token.nextToken());
				bikeDeposit.setText(token.nextToken());
				
			}			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	@FXML
	public void backButtonPushed(ActionEvent e) throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Home.fxml"));
		Scene scene = new Scene(root);
		
		Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
		
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Northampton Bike Hire System | Home");
		secondaryStage.show();
	}
	
	@FXML
	public void calculateButtonPushed(ActionEvent e) throws ParseException
	{	
		if(!(cusName.getText().isEmpty()) && !(cusPhone.getText().isEmpty()) && !(cusAddress.getText().isEmpty()) && (!hireHours.getText().isEmpty() ||  !hireDays.getText().isEmpty()))
		{
			emptyField.setText("");
			
			
			boolean phoneNumericValidation = Validator.numericValidation(cusPhone, phoneError, "Please enter only numbers from 0-9");
			boolean hireHoursNumericValidation = true;
			boolean hireDaysNumericValidation = true;
			
			if(!hireHours.getText().isEmpty())
			{
				hireHoursNumericValidation = Validator.numericValidation(hireHours, hireHoursNumericError, "Please enter only numbers from 0-9");
			}
			if(!hireDays.getText().isEmpty())
			{
				hireDaysNumericValidation = Validator.numericValidation(hireDays, hireDaysNumericError, "Please enter only numbers from 0-9");
			}
			
			if(!(hireHours.getText().isEmpty()) && !(hireDays.getText().isEmpty()))
			{
				emptyField.setText("Only one(Hire Days or Hire Hours) field is supposed to be filled.");
			}
			else if(!(hireHours.getText().isEmpty()) && (hireDays.getText().isEmpty()))
			{
				if(hireHoursNumericValidation && phoneNumericValidation )
				{
					int totalHireHours = Integer.parseInt(hireHours.getText());
					totalAmount = Double.toString(calculateAmount(totalHireHours,0, Double.parseDouble(bikeHourlyRate.getText()), Double.parseDouble(bikeDailyRate.getText()),  Double.parseDouble(bikeDeposit.getText())));
					filledName = cusName.getText();
					filledPhone = cusPhone.getText();
					filledAddress = cusAddress.getText();
					filledHireHours = hireHours.getText();
					filledHireDays = hireDays.getText();
					loadTotalAmountWindow(e);
				}
			}
			
			else if(!(hireDays.getText().isEmpty()) && (hireHours.getText().isEmpty()))
			{
				if(hireDaysNumericValidation && phoneNumericValidation )
				{
					int totalHireDays = Integer.parseInt(hireDays.getText());
					totalAmount = Double.toString(calculateAmount(0,totalHireDays,Double.parseDouble(bikeHourlyRate.getText()), Double.parseDouble(bikeDailyRate.getText()),  Double.parseDouble(bikeDeposit.getText())));
					filledName = cusName.getText();
					filledPhone = cusPhone.getText();
					filledAddress = cusAddress.getText();
					filledHireHours = hireHours.getText();
					filledHireDays = hireDays.getText();
					loadTotalAmountWindow(e);
					
				}
			}
		}
		else
		{
			emptyField.setText("One or more fields are empty.");	
		}
		
	}
	
	public double calculateAmount(int hireHours, int hireDays, double hourlyHireRate, double dailyHireRate, double depositRate )
	{
		if(hireDays==0)
		{
			if(hireHours>0)
			{
				return (hireHours*(hourlyHireRate) + depositRate);
			}
			else
			{
				return 0.0;
			}
				
		}
		else if(hireHours == 0)
		{
			if(hireDays>0)
			{
				return (hireDays*(dailyHireRate)+ depositRate);
			}
			else
			{
				return 0.0;
			}
		}
		return 0.0;
	}
	
	
	@FXML
	private void loadTotalAmountWindow(ActionEvent e) 
	{
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/TotalAmount.fxml"));
			Scene scene = new Scene(root);
			Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Northampton Bike Hire System | Total Amount");
			secondaryStage.show();
			} catch (IOException ex) {
				ex.printStackTrace();
			}		
	}

}

package bikeHireApplication;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HireInvoiceHandler implements Initializable{

	@FXML
	private Label bikeType;
	@FXML
	private Label bikeNo;
	@FXML
	private Label bikeMake;
	@FXML
	private Label bikeColor;
	@FXML
	private Label bikeGender;
	@FXML
	private Label bikeSize;
	@FXML
	private Label bikeHourlyRate;
	@FXML
	private Label bikeDailyRate;
	@FXML
	private Label bikeDeposit;
	@FXML
	private Label HireDate;
	@FXML
	private Label cusName;
	@FXML
	private Label cusPhone;
	@FXML
	private Label cusAddress;
	@FXML
	private Label hireHours;
	@FXML
	private Label hireDays;
	@FXML
	private Label totalAmount;

	@FXML
	private Button OK;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		cusName.setText(HireBikeHandler.filledName);//1
		cusPhone.setText(HireBikeHandler.filledPhone);//2
		cusAddress.setText(HireBikeHandler.filledAddress);//3
		String hours = HireBikeHandler.filledHireHours.equalsIgnoreCase("") ? "0" : HireBikeHandler.filledHireHours;  
		hireHours.setText(hours);//4
		String days = HireBikeHandler.filledHireDays.equalsIgnoreCase("") ? "0" : HireBikeHandler.filledHireDays;  
		hireDays.setText(days);//5
		HireDate.setText(new Date().toString());//6
		totalAmount.setText(HireBikeHandler.totalAmount);//7
		
		StringTokenizer token = new StringTokenizer(HireBikeHandler.searchedData, ">");
		
		bikeType.setText(token.nextToken());//8
		bikeGender.setText(token.nextToken());//9
		bikeSize.setText(token.nextToken());//10
		bikeColor.setText(token.nextToken());//11
		token.nextToken();
		bikeNo.setText(token.nextToken());//12
		bikeMake.setText(token.nextToken());//13
		bikeHourlyRate.setText(token.nextToken());//14
		bikeDailyRate.setText(token.nextToken());//15
		bikeDeposit.setText(token.nextToken());//16
	}
	
	@FXML
	public void OkButtonPressed(ActionEvent e) throws IOException
	{
		HireBikeHandler.filledAddress = "";
		HireBikeHandler.filledName = "";
		HireBikeHandler.filledPhone = "";
		HireBikeHandler.filledHireHours = "";
		HireBikeHandler.filledHireDays = "";
		
		Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Home.fxml"));
		Scene scene = new Scene(root);
		
		Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
		
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Northampton Bike Hire System | Home");
		secondaryStage.show();
	}

}

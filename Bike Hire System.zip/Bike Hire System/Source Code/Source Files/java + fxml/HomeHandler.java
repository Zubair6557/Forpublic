package bikeHireApplication;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.control.ComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.scene.control.Button;


import javafx.stage.Stage;

public class HomeHandler implements Initializable{

	@FXML
	private Button logout;
	@FXML
	private Button checkAvailability;
	@FXML
	private Button getDetails;
	@FXML
	private Label bikeStatus;
	@FXML
	private TextField customerName;
	@FXML
	private TextField customerPhone;
	@FXML
	private Label returnError;
	@FXML
	private Label phoneError;
	@FXML
	private  ComboBox<String> bikeCategory;
	@FXML
	private ComboBox<String> bikeGender;
	@FXML
	private ComboBox<String> bikeSize;
	@FXML
	private ComboBox<String> bikeColor;
	
	
	public static String selectedCategory;
	public static String selectedGender;
	public static String selectedSize;
	public static String selectedcolor;
	public static String filledName;
	public static String filledPhone;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		bikeStatus.setText("");
		
	}
	
	@FXML
	public void searchButtonPushed(ActionEvent event ) throws Exception
	{
		bikeStatus.setText("");
		AvailableStockFileHandler bike = new AvailableStockFileHandler();
		bike.category = bikeCategory.getValue();
		bike.gender = bikeGender.getValue();
		bike.frameSize = bikeSize.getValue();
		bike.color = bikeColor.getValue();
		
		if(AvailableStockFileHandler.CheckAvailability(bike))
		{
			selectedCategory = bikeCategory.getValue();
			selectedGender = bikeGender.getValue();
			selectedSize = bikeSize.getValue();
			selectedcolor = bikeColor.getValue();
			
			Parent root;
			try {
				root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Hire.fxml"));
				Scene scene = new Scene(root);
				Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
				secondaryStage.setScene(scene);
				secondaryStage.setTitle("Northampton Bike Hire System | Hire Bike");
				secondaryStage.show();
				} catch (IOException ex) {
					ex.printStackTrace();
				}		
			bikeStatus.setText("");
		}
		else
		{
			
			bikeStatus.setText("Bike not found!");
		}
	}

	@FXML
	public void logoutButtonPushed(ActionEvent event )
	{
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Login.fxml"));
			Scene scene = new Scene(root);
			Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Northampton Bike Hire System | Login");
			secondaryStage.show();
			} catch (IOException ex) {
				ex.printStackTrace();
			}		
	}
	
	
	
	
	@FXML
	public void ReturnDetailsButtonPushed(ActionEvent event ) throws Throwable 
	{
		if(customerName.getText().isEmpty() && customerPhone.getText().isEmpty())
		{
			returnError.setText("Empty Fields");
		}
		else
		{
			if(!(customerPhone.getText().isEmpty()))
			{
				if(Validator.numericValidation(customerPhone, phoneError, "Please enter only numbers from 0-9"))
				{
					if(HiredBikesFileHandler.searchHiredBike(customerName.getText(), customerPhone.getText()))
					{
						filledName = customerName.getText();
						filledPhone = customerPhone.getText();
						
						Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Return.fxml"));
						Scene scene = new Scene(root);
						Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
						secondaryStage.setScene(scene);
						secondaryStage.setTitle("Northampton Bike Hire System | Return Bike");
						secondaryStage.show();
					}
					else
					{
						returnError.setText("Details not found!");
					}
				}		
			}
			else
			{
				if(HiredBikesFileHandler.searchHiredBike(customerName.getText(), customerPhone.getText()))
				{
					filledName = customerName.getText();
					filledPhone = customerPhone.getText();
					
					Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Return.fxml"));
					Scene scene = new Scene(root);
					Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
					secondaryStage.setScene(scene);
					secondaryStage.setTitle("Northampton Bike Hire System | Return Bike");
					secondaryStage.show();
				}
				else
				{
					returnError.setText("Details not Found");
				}
			}
		}		
	}
}

package bikeHireApplication;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class TotalAmountHandler implements Initializable{

	
	@FXML
	private Button confirmHire;
	@FXML
	private Button back;
	@FXML
	private Label totalAmount;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		totalAmount.setText(" � " + HireBikeHandler.totalAmount);
		
	}
	
	@FXML
	public void confirmButtonPressed(ActionEvent e) throws NumberFormatException, IOException
	{
		HiredBikesFileHandler hiredBikeData = new HiredBikesFileHandler();
		AvailableStockFileHandler bike = new AvailableStockFileHandler();
		
		hiredBikeData.cusName = HireBikeHandler.filledName;//1
		hiredBikeData.cusPhone = HireBikeHandler.filledPhone;//2
		hiredBikeData.cusAddress = HireBikeHandler.filledAddress;//3
		hiredBikeData.hireHours = HireBikeHandler.filledHireHours.equalsIgnoreCase("") ? "0" : HireBikeHandler.filledHireHours;//4  
		hiredBikeData.hireDays = HireBikeHandler.filledHireDays.equalsIgnoreCase("") ? "0" : HireBikeHandler.filledHireDays;//5  
		hiredBikeData.HireDate = HireBikeHandler.hireDate.toString();//6
		hiredBikeData.totalAmount =  HireBikeHandler.totalAmount;//7
		
		StringTokenizer token = new StringTokenizer(HireBikeHandler.searchedData, ">");
		
		bike.category = hiredBikeData.bikeType = token.nextToken(); //8
		bike.gender =  hiredBikeData.bikeGender = token.nextToken();//9
		bike.frameSize = hiredBikeData.bikeSize = token.nextToken();//10
		bike.color = hiredBikeData.bikeColor = token.nextToken();//11
		bike.quantity = token.nextToken();
		bike.bikeNo = hiredBikeData.bikeNo = token.nextToken();//12
		bike.make = hiredBikeData.bikeMake = token.nextToken();//13
		bike.hourlyHireRate = hiredBikeData.bikeHourlyRate = token.nextToken();//14
		bike.dailyHireRate = hiredBikeData.bikeDailyRate = token.nextToken();//15
		bike.depositFee = hiredBikeData.bikeDeposit = token.nextToken();//16
		
		HiredBikesFileHandler.addNewHiredBike(hiredBikeData);
		AvailableStockFileHandler.updateAvailableBikes(bike);
		
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/HireInvoice.fxml"));
			Scene scene = new Scene(root);
			Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Northampton Bike Hire System | Hire Invoice");
			secondaryStage.show();
			} catch (IOException ex) {
				ex.printStackTrace();
			}		
	}
	
	@FXML
	public void backButtonPressed(ActionEvent e)
	{
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Hire.fxml"));
			Scene scene = new Scene(root);
			Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Northampton Bike Hire System | Hire Bike");
			secondaryStage.show();
			} catch (IOException ex) {
				ex.printStackTrace();
			}		
	}
}

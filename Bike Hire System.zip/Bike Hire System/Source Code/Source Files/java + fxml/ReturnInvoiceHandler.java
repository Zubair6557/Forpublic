package bikeHireApplication;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ReturnInvoiceHandler implements Initializable{
	
	@FXML
	private Label bikeType;
	@FXML
	private Label bikeNo;
	@FXML
	private Label bikeMake;
	@FXML
	private Label bikeColor;
	@FXML
	private Label bikeGender;
	@FXML
	private Label bikeSize;
	@FXML
	private Label bikeDeposit;
	@FXML
	private Label hireDate;
	@FXML
	private Label returnDate;
	@FXML
	private Label cusName;
	@FXML
	private Label cusPhone;
	@FXML
	private Label cusAddress;
	@FXML
	private Label hireHours;
	@FXML
	private Label hireDays;
	@FXML
	private Label lateHours;
	@FXML
	private Label lateDays;
	@FXML
	private Label paid;
	@FXML
	private Label refundable;
	@FXML
	private Label lateFee;
	@FXML
	private Label bikeCondition;

	@FXML
	private Button OK;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		String str;
		try {
			
			str = HiredBikesFileHandler.getHiredBikeDetails(ReturnBikeHandler.rCusName, ReturnBikeHandler.rCusPhone);
			StringTokenizer newToken = new StringTokenizer(str, ">");
		
			cusName.setText(newToken.nextToken());
			cusPhone.setText(newToken.nextToken());
			cusAddress.setText(newToken.nextToken());
			hireDate.setText(newToken.nextToken());
			bikeNo.setText(newToken.nextToken());
			bikeType.setText(newToken.nextToken());
			bikeColor.setText(newToken.nextToken());
			bikeGender.setText(newToken.nextToken());
			bikeMake.setText(newToken.nextToken());
			bikeSize.setText(newToken.nextToken());
			newToken.nextToken();
			newToken.nextToken();
			bikeDeposit.setText(newToken.nextToken());
			hireHours.setText(newToken.nextToken());
			hireDays.setText(newToken.nextToken());
			paid.setText(newToken.nextToken());

			returnDate.setText(new Date().toString());
			String lHours = ReturnBikeHandler.lateReturnHours.equalsIgnoreCase("") ? "0" : ReturnBikeHandler.lateReturnHours;
			lateHours.setText(lHours);
			String lDays = ReturnBikeHandler.lateReturnDays.equalsIgnoreCase("") ? "0" : ReturnBikeHandler.lateReturnDays;
			lateDays.setText(lDays);
			bikeCondition.setText(ReturnBikeHandler.condition);
			refundable.setText(ReturnBikeHandler.refundable);
			lateFee.setText(ReturnBikeHandler.lateReturnFee);
			
			String delim = ">";
			String customerAfterReturnRecord;
			customerAfterReturnRecord = cusName.getText() +delim+  cusPhone.getText() +delim+ cusAddress.getText() +delim+ hireDate.getText() +delim+ returnDate.getText() +delim+ bikeNo.getText() +delim+ bikeType.getText() +delim+ bikeColor.getText() +delim+ bikeGender.getText() +delim+ bikeMake.getText() +delim+ bikeSize.getText() +delim+ bikeDeposit.getText() +delim+ hireHours.getText() +delim+ hireDays.getText() +delim+ paid.getText() +delim+ lateHours.getText() +delim+ lateDays.getText() +delim+ bikeCondition.getText() +delim+ refundable.getText() +delim+ lateFee.getText();
			
			try {
				HiredBikesFileHandler.updatePaymentData(customerAfterReturnRecord);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@FXML
	public void OkButtonPressed(ActionEvent e) throws IOException
	{
		HireBikeHandler.filledAddress = "";
		HireBikeHandler.filledName = "";
		HireBikeHandler.filledPhone = "";
		HireBikeHandler.filledHireHours = "";
		HireBikeHandler.filledHireDays = "";
		
		Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Home.fxml"));
		Scene scene = new Scene(root);
		
		Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
		
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Northampton Bike Hire System | Home");
		secondaryStage.show();
	}



}

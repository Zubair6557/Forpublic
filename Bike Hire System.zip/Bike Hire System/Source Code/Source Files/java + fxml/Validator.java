package bikeHireApplication;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Validator {

	    public static boolean numericValidation(TextField textField, Label label, String errorText) {
	        boolean numeric = true;
	        String str = "";
	        
	        if (!textField.getText().matches("[0-9]+")) {
	            numeric = false;
	            str = errorText;
	        }
	        label.setText(str);
	        return numeric;
	    }
}

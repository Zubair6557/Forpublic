package bikeHireApplication;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculateMethodTesting {

	@Test
	void testCalculateAmount() {
		
		HireBikeHandler test = new HireBikeHandler();
		//When Uncorrect Expected value is given 
		assertEquals(38, test.calculateAmount(0, 1,3.495,9.99,30));
	}

}

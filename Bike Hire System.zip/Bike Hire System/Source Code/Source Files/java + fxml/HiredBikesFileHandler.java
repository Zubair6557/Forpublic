package bikeHireApplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class HiredBikesFileHandler {
	
	
	public  String bikeType;
	public  String bikeNo;
	public  String bikeMake;
	public  String bikeColor;
	public  String bikeGender;
	public  String bikeSize;
	public  String bikeHourlyRate;
	public  String bikeDailyRate;
	public  String bikeDeposit;
	public  String HireDate;
	public  String cusName;
	public  String cusPhone;
	public  String cusAddress;
	public  String hireHours;
	public  String hireDays;
	public  String totalAmount;
	
	
	public static void addNewHiredBike(HiredBikesFileHandler hireData)
	{
		try{     
	         
			String delim = ">";
			PrintWriter pwr = new PrintWriter(new FileWriter("HiredStock.txt",true));
			pwr.println(hireData.cusName +delim+ hireData.cusPhone +delim+ hireData.cusAddress +delim+ hireData.HireDate + delim+ hireData.bikeNo +delim+ hireData.bikeType +delim+ hireData.bikeColor +delim+ hireData.bikeGender +delim+ hireData.bikeMake +delim+ hireData.bikeSize +delim+ hireData.bikeDailyRate +delim+ hireData.bikeHourlyRate +delim+ hireData.bikeDeposit +delim+ hireData.hireHours +delim+ hireData.hireDays +delim+ hireData.totalAmount);
            pwr.close();
            
            }catch(Exception ex){
            ex.printStackTrace();
            }
	}
	
		
	public static boolean searchHiredBike(String name, String phone) throws IOException
	{	
		try {
			File myFile = new File("HiredStock.txt"); 
			BufferedReader brd = new BufferedReader(new FileReader(myFile));
			String str;

			while ((str = brd.readLine())!= null) 
			{       
			     StringTokenizer token = new StringTokenizer(str, ">");
			     
			     
			     if(!(name.isEmpty()) && phone.isEmpty())
			     {
			    	if(name.equalsIgnoreCase(token.nextToken()))
				    {
				   		brd.close();
				   		return true;
				   	}
			     }
			     else if(!(name.isEmpty()) && !(phone.isEmpty()))
			     {
			    	if(name.equalsIgnoreCase(token.nextToken()) && phone.equalsIgnoreCase(token.nextToken()))
			    	{
			    		brd.close();
			    		return true;
			    	}
			     }
			     else if((name.isEmpty()) && !(phone.isEmpty()))
			     {
			    	 token.nextToken();
			    	if(phone.equalsIgnoreCase(token.nextToken()))
					{
				  		brd.close();
				   		return true;
				   	}
			     }
			 }
			
			brd.close();
			return false;
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} 
		return false;
	}

	public static String getHiredBikeDetails(String name, String phone) throws IOException
	{
		String str="";
		try {
			File file = new File("HiredStock.txt"); 
			BufferedReader brd = new BufferedReader(new FileReader(file));
			
			
			
			while ((str = brd.readLine())!= null) 
			{       
			    
				StringTokenizer myTokens = new StringTokenizer(str, ">");
			     
			     if(!(name.isEmpty()) && !(phone.isEmpty()))
			     {
			
			    	 
			    	if(name.equalsIgnoreCase(myTokens.nextToken()) && phone.equalsIgnoreCase(myTokens.nextToken()))
			    	{
			    		
			    		brd.close();
			    		return str;
			    	}
			     }
			     else if(!(name.isEmpty()) && phone.isEmpty())
			     {
			
			    	if(name.equalsIgnoreCase(myTokens.nextToken()))
				    {
			    		brd.close();
			    		return str;
				   	}
			     }
			     else if((name.isEmpty()) && !(phone.isEmpty()))
			     {
			
			    	 myTokens.nextToken();
			    	if(phone.equalsIgnoreCase(myTokens.nextToken()))
					{
			    		brd.close();
			    		return str;
				   	}
			     }
			 }
			brd.close();
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} 
		
		return str;
	}
	
	public static void removeHiredBike(String name, String phone) throws Exception
	{
			
		File hiredFile = new File("HiredStock.txt");
		BufferedReader brd = new BufferedReader(new FileReader(hiredFile));
		
		File tempFile = new File("temp.txt");
		PrintWriter pwr = new PrintWriter(new FileWriter(tempFile,true));
		
		String custName, custPhone;
		String delim = ">";
		String str;
		
		while ((str = brd.readLine())!= null) 
		{       
		    StringTokenizer token = new StringTokenizer(str, delim);
		    custName = token.nextToken();
		    custPhone = token.nextToken();
		    
		    if(!name.equalsIgnoreCase(custName) && !phone.equalsIgnoreCase(custPhone))
	    	{
	    		 pwr.println(str);
	    	}		     		        
		}
		pwr.close();
		brd.close();

		hiredFile.delete();
		tempFile.renameTo(hiredFile);
		
	}
	
	public static void updatePaymentData(String data) throws Exception
	{		
		File recordFile = new File("AfterReturnRecord.txt");
		PrintWriter pwr = new PrintWriter(new FileWriter(recordFile,true));
		pwr.println(data);
		pwr.close();
				
	}

	
}

package bikeHireApplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class AvailableStockFileHandler {
	
	public String category;
	public String gender;
	public String frameSize;
	public String color;
	public String quantity;
	public String bikeNo;
	public String make;
	public String hourlyHireRate;
	public String dailyHireRate;
	public String depositFee;
	
	
	public static boolean CheckAvailability(AvailableStockFileHandler bike) throws IOException
	{
		
		try {
			File myFile = new File("AvailableStock.txt"); 
			BufferedReader br = new BufferedReader(new FileReader(myFile));
			String delim = ">";
			String str;
			
			while ((str = br.readLine())!= null) 
			{       
			     StringTokenizer token = new StringTokenizer(str, delim);
			     if(token.nextToken().equalsIgnoreCase(bike.category) && token.nextToken().equalsIgnoreCase(bike.gender) && token.nextToken().equalsIgnoreCase(bike.frameSize) && token.nextToken().equalsIgnoreCase(bike.color) && Integer.parseInt(token.nextToken()) > 0)
			     {
			    	 br.close();
			    	 return true;
			     }
			 }
			br.close();	
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
		return false;
	}

	
	public static String getAvailableBikeDetail(AvailableStockFileHandler bike) throws IOException
	{
		
		String str = "";
		try {
			File file = new File("AvailableStock.txt"); 
			BufferedReader br = new BufferedReader(new FileReader(file));
			String delim = ">";
			
			while ((str = br.readLine())!= null) 
			{       
			     StringTokenizer token = new StringTokenizer(str, delim);
			     if(token.nextToken().equalsIgnoreCase(bike.category) && token.nextToken().equalsIgnoreCase(bike.gender) && token.nextToken().equalsIgnoreCase(bike.frameSize) && token.nextToken().equalsIgnoreCase(bike.color) )
			     {
			    	 br.close();
			    	 break;
			     }
		
			 }
			br.close();	
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} 
		
		return str;
	}
	
	//Atfer Hiring a bike, Quantity = -1
	public static void updateAvailableBikes(AvailableStockFileHandler bike) throws NumberFormatException, IOException
	{
		File oldFile = new File("AvailableStock.txt");
		BufferedReader br = new BufferedReader(new FileReader(oldFile));
		
		
		File updatedFile = new File("temp.txt");
		PrintWriter pw = new PrintWriter(new FileWriter(updatedFile,true));
		
		String str, updatedQuantity, delim = ">";
		
		while ((str = br.readLine())!= null) 
		{       
		    StringTokenizer token = new StringTokenizer(str, delim);
		     
		     if(bike.category.equalsIgnoreCase(token.nextToken()) && bike.gender.equalsIgnoreCase(token.nextToken()) && bike.frameSize.equalsIgnoreCase(token.nextToken()) && bike.color.equalsIgnoreCase(token.nextToken()) && (!(bike.quantity.equalsIgnoreCase("0"))) && !token.nextToken().isEmpty() && bike.bikeNo.equalsIgnoreCase(token.nextToken()) && bike.make.equalsIgnoreCase(token.nextToken()))
		     {
			  	 updatedQuantity = Integer.toString(Integer.parseInt(bike.quantity)-1);			  	 
			  	 str =  bike.category +delim+ bike.gender +delim+ bike.frameSize +delim+ bike.color +delim+ updatedQuantity +delim+ bike.bikeNo +delim+ bike.make +delim+ bike.hourlyHireRate +delim+ bike.dailyHireRate +delim+ bike.depositFee;
			  	pw.println(str);
		     }
		     else
		     {
		     	 pw.println(str);	 
		     }		        
		}
		pw.close();
		br.close();
		
		oldFile.delete();
		updatedFile.renameTo(oldFile);
	}
	
	//After returning a bike, Quantity = +1
	public static void updateAvailableStock(AvailableStockFileHandler bike) throws IOException
	{
		File oldFile = new File("AvailableStock.txt");
		BufferedReader br = new BufferedReader(new FileReader(oldFile));
		
		
		File updatedFile = new File("temp.txt");
		PrintWriter pw = new PrintWriter(new FileWriter(updatedFile,true));
		
		String str, updatedQuantity, delim = ">";
		String bCategory, bGender, bSize, bColor, bQunantity, bNo, bMake, bDailyRate, bHourlyRate, bDeposit;  
		
		while ((str = br.readLine())!= null) 
		{       
		    StringTokenizer token = new StringTokenizer(str, delim);
		    bCategory = token.nextToken();
		    bGender = token.nextToken();;
		    bSize = token.nextToken();
		    bColor = token.nextToken();
		    bQunantity = token.nextToken();
		    bNo = token.nextToken();
		    bMake = token.nextToken();
		    bHourlyRate = token.nextToken();
		    bDailyRate = token.nextToken();		    
		    bDeposit = token.nextToken();
		     
		     if(bike.category.equalsIgnoreCase(bCategory) && bike.gender.equalsIgnoreCase(bGender) && bike.frameSize.equalsIgnoreCase(bSize) && bike.color.equalsIgnoreCase(bColor) && bike.bikeNo.equalsIgnoreCase(bNo) && bike.make.equalsIgnoreCase(bMake))
		     {
			  	 updatedQuantity = Integer.toString(Integer.parseInt(bQunantity)+1);	  	 
			  	 str =  bike.category +delim+ bike.gender +delim+ bike.frameSize +delim+ bike.color +delim+ updatedQuantity +delim+ bike.bikeNo +delim+ bike.make +delim+ bHourlyRate +delim+ bDailyRate +delim+ bDeposit;
			  	pw.println(str);
		     }
		     else
		     {
		     	 pw.println(str);	 
		     }		        
		}
		pw.close();
		br.close();
		
		oldFile.delete();
		updatedFile.renameTo(oldFile);	
		}

}

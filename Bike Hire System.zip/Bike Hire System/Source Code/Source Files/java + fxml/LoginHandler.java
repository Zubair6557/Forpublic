package bikeHireApplication;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginHandler implements Initializable{
	
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Button login;
	@FXML
	private Label error;
	
	private final String[] USERNAMES = {"John", "Jasper", "Ada"};
	private final String[] PASSWORDS = {"1234", "5678", "9123"};
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	
		error.setText("");
		
	}
	
	@FXML
	public void loginButtonPressed(ActionEvent e) throws IOException
	{
		error.setText("");
		boolean valid = false;
		for(int i=0; i<USERNAMES.length; i++)
		{
			if(username.getText().equalsIgnoreCase(USERNAMES[i]) && password.getText().equalsIgnoreCase(PASSWORDS[i]))
			{
				valid = true;
				break;
			}
		}
		
		if(valid)
		{
			Parent root = FXMLLoader.load(getClass().getResource("/bikeHireApplication/Home.fxml"));
			Scene scene = new Scene(root);
			
			Stage secondaryStage = (Stage)((Node)e.getSource()).getScene().getWindow();
			
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Northampton Bike Hire System | Home");
			secondaryStage.show();
		}
		else
		{
			error.setText("Login Failed!");
		}
	}

	

}
